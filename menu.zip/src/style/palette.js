// src/styles/palette.js
export const PALETTE = {
  slate:  "#3C4B59",
  mustard:"#E3C85C",
  coral:  "#F16C5B",
  teal:   "#53C1C2",
  purple: "#8D6BB0",
  pink:   "#F49AB9",
  mango:  "#F3A23A",
  sand:   "#FFF4CF", // page bg
};
