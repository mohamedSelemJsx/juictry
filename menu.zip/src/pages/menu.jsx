// src/pages/MenuPage.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import BackgroundLogo from "../components/BG_Logo";
import BGChemistryPattern from "../components/BG_ChemistryPattern.jsx";
import { PALETTE } from "../style/palette.js";
import logo2 from "../assets/logo2.png"

const API_BASE = "https://bbbbbbb-l94i.onrender.com"; // proxy to your backend

export default function MenuPage() {
  const [searchParams, setSearchParams] = useSearchParams();

  const [categories, setCategories] = useState([]);
  const [catState, setCatState] = useState("loading");
  const [activeId, setActiveId] = useState(() => searchParams.get("typeId") || null);

  const [items, setItems] = useState([]);
  const [itemsState, setItemsState] = useState("idle");

  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  // fetch categories
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setCatState("loading");
        const res = await fetch(`${API_BASE}/types`, { headers: { Accept: "application/json" } });
        if (!res.ok) throw new Error("bad status");
        const json = await res.json();
        const norm = (Array.isArray(json) ? json : json?.data || []).map((c, i) => ({
          id: c.id ?? i,
          name: c.name ?? "Category",
        }));
        if (cancelled) return;
        setCategories(norm);
        setCatState("ready");
      } catch {
        if (!cancelled) setCatState("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // fetch items for active category
  useEffect(() => {
    if (!activeId) return;
    let cancelled = false;
    (async () => {
      try {
        setItemsState("loading");
        const res = await fetch(`${API_BASE}/types/by-id?id=${activeId}`, {
          headers: { Accept: "application/json" },
        });
        if (!res.ok) throw new Error("bad status");
        const data = await res.json();
        if (cancelled) return;

        const menus = Array.isArray(data?.menus) ? data.menus : [];
        const norm = menus.map((m, i) => ({
          id: m.id ?? i,
          title: m.name ?? "Item",
          price: m.price ?? null,
          image: m.image ?? null,
          description1: m.description1 ?? "",
          description2: m.description2 ?? "",
        }));
        setItems(norm);
        setItemsState(norm.length ? "ready" : "empty");
      } catch {
        if (!cancelled) setItemsState("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  const filtered = useMemo(() => items, [items]);

  const selectCategory = (id) => {
    setActiveId(String(id));
    setSearchParams({ typeId: String(id) });
  };

  const clearCategory = () => {
    setActiveId(null);
    setSearchParams({});
  };

  const onHome = !activeId;

  return (
    <div className="relative min-h-screen antialiased bg-gradient-to-br from-gray-100 to-gray-200">
      {/* darker corners */}
      <div className="pointer-events-none absolute inset-0 z-0 bg-[radial-gradient(circle_at_top_left,rgba(0,0,0,0.06),transparent_70%),radial-gradient(circle_at_bottom_right,rgba(0,0,0,0.08),transparent_70%)]" />
      <BackgroundLogo />
      <BGChemistryPattern />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6 md:py-8 lg:py-10">
        {/* Logo centered */}
        <div className="flex items-center justify-center relative">
          <img
            src={logo2}
            alt="Juicetry Logo"
            className="h-14 sm:h-16 md:h-20 object-contain"
          />
          {!onHome && (
            <button
              onClick={clearCategory}
              className="absolute left-0 top-1/2 -translate-y-1/2 rounded-full px-3 py-1.5 text-sm font-medium ring-1 ring-black/10 bg-white/40 backdrop-blur-sm hover:bg-white/60 transition"
              style={{ color: PALETTE.slate }}
            >
              ← All Categories
            </button>
          )}
        </div>

        {/* ---------------- HOME: CATEGORIES LIST ---------------- */}
        {onHome && (
          <>
            <div className="text-[11px] uppercase tracking-widest text-[#3C4B59]/70 text-center mt-2">
              Categories
            </div>

            <section className="mt-6 grid gap-3 grid-cols-1">
              {catState === "loading" &&
                Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-16 rounded-2xl bg-white/30 backdrop-blur-md animate-pulse" />
                ))}
              {catState === "error" && (
                <p className="text-sm" style={{ color: PALETTE.slate }}>
                  Failed to load categories.
                </p>
              )}
              {catState === "ready" &&
                categories.map((c) => (
                  <CategoryTile key={c.id} cat={c} onClick={() => selectCategory(c.id)} />
                ))}
            </section>
          </>
        )}

        {/* ---------------- ITEMS VIEW ---------------- */}
        {!onHome && (
          <main className="mt-6">
            {itemsState === "loading" && <p style={{ color: PALETTE.slate }}>Loading…</p>}
            {itemsState === "error" && <p style={{ color: "#d43c3c" }}>Error loading items.</p>}
            {itemsState === "empty" && <p style={{ color: PALETTE.slate }}>No items.</p>}

            {itemsState === "ready" && (
              <div className="grid gap-4 sm:gap-6 grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {filtered.map((it) => (
                  <PosterCard key={it.id} item={it} />
                ))}
              </div>
            )}
          </main>
        )}
      </div>
    </div>
  );
}

/* ---------- Category Tile ---------- */
function CategoryTile({ cat, onClick }) {
  return (
    <button
      onClick={onClick}
      className="rounded-2xl w-full h-16 bg-white/30 backdrop-blur-md ring-1 ring-black/10 hover:border-2 hover:border-[#2F3C48] transition-all flex items-center justify-between px-4"
      style={{ color: PALETTE.slate }}
    >
      <span className="text-base sm:text-lg font-medium">{cat.name}</span>
      <span className="text-[11px] sm:text-xs opacity-60">View</span>
    </button>
  );
}

/* ---------- Item Card + modal ---------- */
function PosterCard({ item }) {
  const [open, setOpen] = React.useState(false);

  // close on Esc
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="rounded-3xl bg-white/30 backdrop-blur-md ring-1 ring-black/10 shadow-sm p-3 sm:p-4 flex items-center gap-3 sm:gap-4 text-left hover:-translate-y-[2px] transition-all w-full"
      >
        {/* image */}
        <div className="shrink-0 w-20 h-24 sm:w-24 sm:h-28 grid place-items-center">
          {item.image ? (
            <img src={item.image} alt={item.title} className="max-h-full max-w-full object-contain" />
          ) : (
            <div className="text-2xl">🥤</div>
          )}
        </div>

        {/* info */}
        <div className="min-w-0 flex-1">
          <h3 className="text-[12px] sm:text-[13px] font-extrabold uppercase text-[#2F3C48] line-clamp-2">
            {item.title}
          </h3>

          {item.description2 && (
            <p className="mt-0.5 text-[11px] sm:text-[12px] text-[#3C4B59]/70 line-clamp-2">
              {item.description2}
            </p>
          )}

          {item.price != null && (
            <div className="mt-1.5">
              <span className="text-[12px] sm:text-[13px] font-semibold text-[#3C4B59]">
                {formatPriceSAR(item.price)}
              </span>
            </div>
          )}
        </div>
      </button>

      {/* Modal */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* backdrop */}
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          {/* dialog */}
          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 max-w-sm w-[90%] rounded-2xl bg-white shadow-xl ring-1 ring-black/10 p-4 sm:p-5"
          >
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-sm sm:text-base font-semibold text-[#2F3C48] leading-snug">
                {item.title}
              </h3>
              <button
                onClick={() => setOpen(false)}
                className="rounded-full px-2 py-1 text-xs ring-1 ring-black/10 hover:bg-gray-100"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="mt-2 text-[13px] sm:text-[14px] text-[#3C4B59]">
              {item.description1 ? item.description1 : "No description available."}
            </div>

            <div className="mt-3 text-right">
              <button
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-1.5 text-sm font-medium ring-1 ring-black/10 bg-gray-50 hover:bg-gray-100"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- utils ---------- */
function formatPriceSAR(val) {
  const num = Number(val);
  return Number.isFinite(num) ? `${num.toFixed(2)} SAR` : `${val} SAR`;
}
